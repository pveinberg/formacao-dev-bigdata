#!/bin/bash

echo "aqui vc usara para colocar toda a criação de pastas que vc achar necessario"