#!/bin/bash

echo "Aqui você colocara os scripts da execução da migração"